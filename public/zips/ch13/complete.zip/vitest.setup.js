import { setProjectAnnotations } from "@storybook/react";
import * as globalStorybookConfig from "./.storybook/preview";

setProjectAnnotations(globalStorybookConfig);
