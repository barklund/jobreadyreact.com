import { LongUserProfile } from "./LongUserProfile";

export default function App() {
  return (
    <main>
      <LongUserProfile userId="1" />
    </main>
  );
}
