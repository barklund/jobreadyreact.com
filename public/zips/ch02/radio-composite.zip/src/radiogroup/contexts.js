import { createContext } from "react";

export const RadioGroupContext = createContext();
export const RadioOptionContext = createContext();
