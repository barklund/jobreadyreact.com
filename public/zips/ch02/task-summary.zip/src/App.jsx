import { LongTaskManager } from "./LongTaskManager";

export default function App() {
  return <LongTaskManager />;
}
