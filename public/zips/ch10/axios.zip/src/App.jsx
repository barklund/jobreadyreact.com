import { StarshipList } from "./StarshipList";

export default function App() {
  return <StarshipList />;
}
