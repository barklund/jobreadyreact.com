import { createContext } from "use-context-selector";

export const DarkModeContext = createContext({});
