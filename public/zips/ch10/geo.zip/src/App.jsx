import { WhereAmI } from "./WhereAmI.jsx";

export default function App() {
  return <WhereAmI />;
}
