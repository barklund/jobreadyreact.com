import { Todo } from "./Todo";

export default function App() {
  return <Todo />;
}
