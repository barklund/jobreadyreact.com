import { createContext } from "react";

const FormatContext = createContext({});
export default FormatContext;
