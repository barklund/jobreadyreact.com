import { createContext } from "react";

export const FormatContext = createContext({});
