import "./useData";
export function DataProvider({ children }) {
  return children;
}
