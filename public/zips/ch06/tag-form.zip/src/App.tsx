import { TagForm } from "./TagForm";

export default function App() {
  return (
    <main>
      <TagForm onTagsChanged={() => {}} />
    </main>
  );
}
