export { StyleProvider } from "./Provider";
export { theme } from "./theme";
export { GlobalStyles } from "./GlobalStyles";
